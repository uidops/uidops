#!/usr/bin/env python

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# ------------------------------
# PATH TO YOUR MERGED MODEL
# ------------------------------
MODEL_PATH = "./output_model"
# ------------------------------

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)

print("Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.float16,
    device_map="auto"
)

# ------------------------------
# INPUT TEXT
# ------------------------------
prompt = "سلام"

# ------------------------------
# GENERATE OUTPUT
# ------------------------------
inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

with torch.no_grad():
    output_tokens = model.generate(
        **inputs,
        max_new_tokens=128,
        # temperature=0.7,
        do_sample=False,
        # top_p=0.9
    )

output_text = tokenizer.decode(output_tokens[0], skip_special_tokens=True)

print("\n=== MODEL OUTPUT ===")
print(output_text)
