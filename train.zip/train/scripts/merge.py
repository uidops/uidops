#!/usr/bin/env python

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

BASE_MODEL = "flax-community/gpt2-persian-question-answering"
ADAPTER = "./"
OUT = "./output_model"

print("Loading base model...")
base = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    torch_dtype=torch.float32,
    device_map="mps"
)

print("Loading LoRA...")
lora = PeftModel.from_pretrained(base, ADAPTER)

print("Merging...")
merged = lora.merge_and_unload()

print("Saving merged model...")
merged.save_pretrained(OUT)
AutoTokenizer.from_pretrained(ADAPTER).save_pretrained(OUT)

print("Done!")
