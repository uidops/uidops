# DIVAN-LM/src/train/trainer.py
import logging
import os
from dataclasses import asdict
from typing import Optional

import torch
from transformers import (
    DataCollatorForLanguageModeling,
    Trainer,
    TrainerCallback,
    TrainerControl,
    TrainerState,
    TrainingArguments,
)

from config import LoRAConfig
from dataset import InstructionQADataset
from model import load_model_and_tokenizer

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def get_preferred_device() -> torch.device:
    """
    Return the best available device: cuda > mps > cpu.
    Works safely across PyTorch versions by checking availability/built flags.
    """
    # CUDA (NVIDIA GPUs)
    if torch.cuda.is_available():
        return torch.device("cuda")

    # Apple MPS (Apple Silicon)
    # Some PyTorch builds expose mps backend availability via torch.backends.mps.is_available()
    is_mps_available = False
    try:
        is_mps_available = (
            getattr(torch.backends, "mps", None) is not None
            and torch.backends.mps.is_available()
        )
    except Exception:
        is_mps_available = False

    if is_mps_available:
        return torch.device("mps")

    # Fallback
    return torch.device("cpu")


def _maybe_set_mps_matmul_precision():
    """
    For Apple Silicon (MPS), set float32 matmul precision to high if available (PyTorch >= 2.1).
    This can help numeric stability / performance on MPS.
    """
    try:
        # This API exists in newer PyTorch versions
        torch.set_float32_matmul_precision("high")
        logger.info(
            "Set float32 matmul precision to 'high' for better MPS performance."
        )
    except Exception:
        # Not available or not applicable; ignore silently
        pass


class SaveOnEpochEnd(TrainerCallback):
    """
    Trainer callback that saves the model and tokenizer at the end of each epoch.

    It writes to <output_dir>/checkpoint-epoch-{N} where N is the epoch index (1-based).
    Uses Trainer.save_model which is compatible with the Hugging Face save format and
    should be loadable in tools expecting a standard Transformers model/tokenizer layout.
    """

    def __init__(self, output_base: Optional[str] = None):
        self.output_base = output_base
        self.trainer = None

    def on_epoch_end(
        self,
        args,
        state: TrainerState,
        control: TrainerControl,
        **kwargs,
    ):
        # Try to retrieve the Trainer instance.
        trainer: Optional[Trainer] = self.trainer or kwargs.get("trainer", None)

        # Determine if this is the main process (only save from main to avoid duplicates).
        if trainer is not None:
            try:
                is_main = getattr(
                    trainer, "is_world_process_zero", lambda: True
                )()
            except Exception:
                is_main = True
        else:
            # If no trainer, assume main process (callback likely only called on main).
            is_main = True

        if not is_main:
            return

        # Determine epoch number; state.epoch can be a float or None (e.g. when resuming).
        epoch_val = state.epoch
        if epoch_val is None:
            # Fallback to global step checkpoint naming if epoch not available
            suffix = f"step-{state.global_step}"
        else:
            # Convert to nearest int (1-based)
            epoch_idx = int(round(epoch_val))
            # Ensure at least 1
            epoch_idx = max(1, epoch_idx)
            suffix = f"epoch-{epoch_idx}"

        # Determine output directory
        if trainer is not None:
            base_output = self.output_base or trainer.args.output_dir
        else:
            # Fallback: use a default or from args if possible
            base_output = self.output_base or getattr(args, "output_dir", ".")
        save_dir = os.path.join(base_output, f"checkpoint-{suffix}")

        # Make sure the directory exists
        os.makedirs(save_dir, exist_ok=True)

        logger.info(f"Saving model and tokenizer at end of epoch -> {save_dir}")

        # Attempt to save using trainer.save_model if available
        saved_successfully = False
        if trainer is not None:
            try:
                trainer.save_model(save_dir)
                saved_successfully = True
                # Save trainer state
                try:
                    trainer.state.save_to_json(
                        os.path.join(save_dir, "trainer_state.json")
                    )
                except Exception:
                    pass
            except Exception as exc:
                logger.warning(
                    f"trainer.save_model failed: {exc}. Attempting fallback save..."
                )

        # If trainer save failed or no trainer, use fallback with model and tokenizer
        if not saved_successfully:
            # Get model and tokenizer
            model = None
            tokenizer = None
            if trainer is not None:
                model = trainer.model
                tokenizer = trainer.tokenizer
            else:
                model = kwargs.get("model")
                tokenizer = kwargs.get("tokenizer")

            if model is None or tokenizer is None:
                logger.error(
                    "Cannot save: model or tokenizer not available in callback."
                )
                return

            # Try to temporarily move model to CPU for safer saving if possible.
            moved = False
            current_device = None
            try:
                current_device = next(model.parameters()).device
            except Exception:
                current_device = None

            try:
                if current_device is not None and current_device.type != "cpu":
                    model.to("cpu")
                    moved = True
            except Exception:
                moved = False

            try:
                if hasattr(model, "save_pretrained"):
                    model.save_pretrained(save_dir)
            except Exception as e:
                logger.error(f"model.save_pretrained failed: {e}")

            try:
                if hasattr(tokenizer, "save_pretrained"):
                    tokenizer.save_pretrained(save_dir)
            except Exception as e:
                logger.error(f"tokenizer.save_pretrained failed: {e}")

            # Move model back to original device if we moved it
            if moved:
                try:
                    model.to(current_device)
                except Exception:
                    # If we can't move it back, continue; training may be interrupted later but we avoid crashing here.
                    pass


def train_lora_model(config: LoRAConfig):
    """Main training function.

    Notes for Apple MPS (e.g. M3/M3 Pro):
    - Hugging Face `Trainer`'s `fp16=True` uses CUDA AMP and is not supported on MPS.
      If you request fp16 on MPS, we disable Trainer's `fp16` and run in full precision.
      Recent PyTorch versions support `torch.autocast(device_type='mps', dtype=torch.float16)`,
      but integrating that safely into Trainer without a custom training loop is non-trivial,
      so we opt for the safer path here.
    - Models are moved to the detected device explicitly.
    """
    # Set deterministic seed
    torch.manual_seed(config.seed)

    # Detect device
    device = get_preferred_device()
    logger.info(f"Using device: {device}")

    if device.type == "mps":
        _maybe_set_mps_matmul_precision()

    # Load model and tokenizer
    logger.info("Loading model and tokenizer...")
    model, tokenizer, bnb, mps = load_model_and_tokenizer(config)

    # Move model to selected device
    try:
        model.to(device)
        logger.info(f"Moved model to {device}")
    except Exception as exc:
        logger.warning(f"Couldn't move model to {device}: {exc}")

    # Disable use_cache during training which can cause issues with some architectures
    try:
        # Some models expose config; others may not
        if hasattr(model, "config"):
            model.config.use_cache = False
    except Exception:
        pass

    # Load dataset
    logger.info("Loading dataset...")
    train_dataset = InstructionQADataset(
        data_path=config.data_path,
        tokenizer=tokenizer,
        max_length=config.max_length,
    )

    # Data collator (causal LM)
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )

    # Resolve optimizer backend/8-bit optimizer availability using loader flags.
    optim_backend = "adamw_torch"
    # Prefer 8-bit optimizer only if the model loader reported bitsandbytes availability (bnb)
    # and a CUDA device is present. Avoid importing bitsandbytes here — the loader already
    # indicated availability.
    if bnb:
        if device.type == "cuda":
            # prefer paged_adamw_8bit if requested fp16 and bitsandbytes available
            if config.fp16:
                optim_backend = "paged_adamw_8bit"
            else:
                optim_backend = "adamw_torch"
        else:
            logger.warning(
                "bitsandbytes reported available by the model loader but no CUDA device detected. "
                "8-bit optimizers require CUDA; falling back to 'adamw_torch'."
            )
            optim_backend = "adamw_torch"
    else:
        # bitsandbytes not available; use adamw_torch
        optim_backend = "adamw_torch"

    # If the loader flagged an MPS-specific model but the runtime device is not MPS, warn the user.
    if mps and device.type != "mps":
        logger.warning(
            f"Model loader indicated an MPS-specific model (mps={mps}) but detected device is {device}. "
            "This may cause performance or compatibility issues."
        )

    # TrainingArguments: modern transformers accept the same keys, but ensure we use safe defaults.
    # Disable fp16 in TrainingArguments when device is mps (Trainer's fp16 uses CUDA AMP).
    training_fp16 = bool(config.fp16) and (device.type == "cuda")

    # Build TrainingArguments with clearer modern defaults
    training_args = TrainingArguments(
        output_dir=config.output_dir,
        overwrite_output_dir=False,
        num_train_epochs=config.num_epochs,
        per_device_train_batch_size=config.batch_size,
        gradient_accumulation_steps=config.gradient_accumulation_steps,
        learning_rate=config.learning_rate,
        warmup_steps=config.warmup_steps,
        logging_dir=config.logging_dir,
        logging_strategy="steps",
        logging_steps=10,
        eval_strategy="no",
        # We keep Trainer's built-in checkpointing separate; our callback will additionally save
        # a model+tokenizer export at the end of every epoch.
        save_strategy="steps",
        save_steps=100,
        save_total_limit=3,
        fp16=training_fp16,
        optim=optim_backend,
        report_to="tensorboard"
        if os.getenv("DISABLE_TENSORBOARD", "0") != "1"
        else None,
        load_best_model_at_end=False,
        # A couple of practical defaults:
        dataloader_drop_last=False,
        disable_tqdm=False,
        push_to_hub=False,
    )

    # Log training args summary for reproducibility and also print to stdout
    try:
        cfg_items = asdict(config).items()
        summary = "Training arguments:\n" + "\n".join([
            f"  {k} = {v}" for k, v in cfg_items
        ])
        logger.info(summary)
        # Also print to stdout for immediate visibility
        print(summary)
    except Exception:
        # Fall back to printing a simpler summary
        summary = f"Training on device={device}, fp16_for_trainer={training_fp16}, optim={optim_backend}"
        logger.info(summary)
        print(summary)

    # Initialize Trainer with our epoch-end saver callback
    epoch_saver = SaveOnEpochEnd(output_base=config.output_dir)
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
        processing_class=tokenizer,
        callbacks=[epoch_saver],
    )
    # Ensure the callback has a reference to the trainer for saving
    epoch_saver.trainer = trainer

    # Start training. If device is mps and user requested fp16, we already disabled Trainer's fp16.
    logger.info("Starting training...")
    trainer.train()

    # Move model to CPU before final saving to avoid device-specific tensors being stored on MPS/GPU
    try:
        model.to("cpu")
    except Exception:
        pass

    # Save final model and tokenizer
    logger.info(f"Saving final model to {config.output_dir}")
    trainer.save_model(config.output_dir)
    tokenizer.save_pretrained(config.output_dir)

    return model, tokenizer


if __name__ == "__main__":
    config = LoRAConfig()
    train_lora_model(config)
