#!/usr/bin/env python

from config import LoRAConfig
from trainer import train_lora_model

if __name__ == "__main__":
    config = LoRAConfig(
        # output_dir="models/persian_qa_lora",
        # num_epochs=3,
        # batch_size=4,
        # learning_rate=2e-4,
    )

    train_lora_model(config)
