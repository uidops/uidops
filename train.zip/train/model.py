"""
Safe model loader with device-aware bitsandbytes usage.

This module provides a helper `load_model_and_tokenizer(config)` which:
- Detects available device (cuda, mps, cpu).
- Attempts to import and enable bitsandbytes (bnb) only when CUDA is available.
- Constructs a BitsAndBytesConfig only when bnb is importable and enabled.
- Loads the tokenizer and model, passing quantization_config to `from_pretrained`
  only when we actually built one (avoids passing None which causes errors).
- Applies PEFT/LoRA and prepares the model for k-bit training if bnb is used.

Intended to be safe to import on Apple Silicon (MPS) and on CPU-only machines.
"""

from __future__ import annotations

import logging
import os
from typing import Optional, Tuple

import torch
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer

logger = logging.getLogger(__name__)


# Runtime detection of devices
def _detect_devices() -> Tuple[bool, bool]:
    """Return tuple (use_cuda, use_mps)."""
    use_cuda = torch.cuda.is_available()
    use_mps = (
        getattr(torch.backends, "mps", None) is not None
        and torch.backends.mps.is_available()
    )
    return use_cuda, use_mps


# Try to conditionally import bitsandbytes and BitsAndBytesConfig only when CUDA is available.
_USE_CUDA, _USE_MPS = _detect_devices()
_HAS_BNB = False
BitsAndBytesConfig = None  # type: ignore

# Allow an environment variable to force-disable bitsandbytes even on CUDA hosts
_force_disable_bnb = os.environ.get("DISABLE_BNB", "").strip() not in ("", "0")
# Allow an environment variable to force-enable bitsandbytes (if installed) on CUDA hosts
_force_enable_bnb = os.environ.get("ENABLE_BNB", "").strip() not in ("", "0")

if _USE_CUDA and not _force_disable_bnb:
    try:
        # Import bitsandbytes only on CUDA systems to avoid import-time failures on Apple Silicon
        import bitsandbytes  # type: ignore

        # BitsAndBytesConfig is currently exported by transformers when bnb is supported
        # Import guarded so that we don't crash on systems lacking bnb.
        from transformers import BitsAndBytesConfig  # type: ignore

        _HAS_BNB = True
        logger.info(
            "bitsandbytes import succeeded; quantization support enabled on CUDA host."
        )
    except Exception as e:
        _HAS_BNB = False
        # Don't raise — we want this module to be safe to import anywhere.
        logger.warning("bitsandbytes not available or failed to import: %s", e)
else:
    if _USE_CUDA:
        logger.info(
            "CUDA is available but bitsandbytes has been force-disabled via DISABLE_BNB."
        )
    else:
        logger.info(
            "CUDA not available; skipping bitsandbytes import on this host."
        )


def _build_bnb_config(fp16_requested: bool) -> Optional[object]:
    """
    Build and return a BitsAndBytesConfig instance if bitsandbytes is available and enabled.

    Returns None if bnb should not be used on this host.
    """
    if not _USE_CUDA or not _HAS_BNB:
        return None

    # Build a config only if fp16 was requested (typical for 4-bit quantization)
    if not fp16_requested and not _force_enable_bnb:
        # If the user explicitly set ENABLE_BNB, we still build the config even without fp16.
        return None

    # Create a BitsAndBytesConfig instance with sensible defaults for training/finetuning.
    # Use kwargs compatible with transformers' integration.
    try:
        # Type ignore: BitsAndBytesConfig may be dynamically available
        bnb_cfg = BitsAndBytesConfig(  # type: ignore
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16
            if fp16_requested
            else torch.float32,
        )
        return bnb_cfg
    except Exception as e:
        logger.warning("Failed to construct BitsAndBytesConfig: %s", e)
        return None


def load_model_and_tokenizer(config) -> Tuple[object, object, bool, bool]:
    """
    Load a causal language model and tokenizer with safe bitsandbytes handling.

    Args:
        config: any object with at least:
            - model_name: str
            - fp16 (optional): bool
            - lora_r, lora_alpha, lora_dropout, target_modules (optional for LoRA)

    Returns:
        model, tokenizer, use_bnb, use_mps

    Notes:
    - `use_bnb` indicates whether bitsandbytes quantization was actually enabled.
    - `use_mps` indicates whether Apple MPS backend is available on this host.
    """
    model_name = getattr(config, "model_name", None)
    if model_name is None:
        raise ValueError("config must have a `model_name` attribute")

    fp16_requested = bool(getattr(config, "fp16", False))

    # Decide whether we will enable bitsandbytes (requires CUDA and bnb importable)
    use_bnb = _USE_CUDA and _HAS_BNB and (fp16_requested or _force_enable_bnb)
    if not _USE_CUDA and _HAS_BNB:
        # Strange situation: bnb import succeeded but CUDA isn't available — be conservative and disable.
        use_bnb = False

    # Build quantization config if applicable
    quantization_config = _build_bnb_config(fp16_requested) if use_bnb else None

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        model_name, trust_remote_code=True
    )
    # Ensure a pad token exists (some tokenizers don't set it)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Determine dtype to request from transformers
    use_mps = _USE_MPS
    if _USE_CUDA:
        torch_dtype = torch.float16 if fp16_requested else None
    elif use_mps:
        # On Apple Silicon, prefer float16 when requested but transformers will place model on MPS.
        torch_dtype = torch.float16 if fp16_requested else None
    else:
        torch_dtype = torch.float32 if not fp16_requested else torch.float16

    # Prepare kwargs for from_pretrained — only include quantization_config when not None
    load_kwargs = {"device_map": "auto", "trust_remote_code": True}
    if quantization_config is not None:
        load_kwargs["quantization_config"] = quantization_config
    if torch_dtype is not None:
        load_kwargs["dtype"] = torch_dtype

    logger.info(
        "Loading model '%s' (use_bnb=%s, use_mps=%s, dtype=%s) with kwargs: %s",
        model_name,
        use_bnb,
        use_mps,
        torch_dtype,
        {
            k: (
                "<quantization_config>"
                if k == "quantization_config"
                else load_kwargs[k]
            )
            for k in load_kwargs
        },
    )

    model = AutoModelForCausalLM.from_pretrained(model_name, **load_kwargs)

    # If bitsandbytes is used, prepare model for k-bit training
    if use_bnb:
        try:
            # prepare_model_for_kbit_training modifies the model in-place to be LoRA/k-bit-friendly
            model = prepare_model_for_kbit_training(model)
        except Exception as e:
            # If preparation fails, warn but continue — user may still want to proceed on CPU/MPS
            logger.warning("prepare_model_for_kbit_training failed: %s", e)

    # Configure LoRA/PEFT
    peft_config = LoraConfig(
        r=getattr(config, "lora_r", 16),
        lora_alpha=getattr(config, "lora_alpha", 16),
        lora_dropout=getattr(config, "lora_dropout", 0.0),
        target_modules=getattr(config, "target_modules", None),
        bias="none",
        task_type="CAUSAL_LM",
    )

    # Apply PEFT/LoRA
    model = get_peft_model(model, peft_config)
    # Print trainable params for debug/visibility; keep it optional in case model lacks method
    try:
        model.print_trainable_parameters()
    except Exception:
        # Not critical; ignore
        pass

    return model, tokenizer, use_bnb, use_mps


# Convenience function for external checks / logging
def summarize_runtime() -> str:
    """Return a short string describing the detected runtime environment."""
    parts = []
    parts.append("cuda_available=" + str(_USE_CUDA))
    parts.append("mps_available=" + str(_USE_MPS))
    parts.append("bitsandbytes_imported=" + str(_HAS_BNB))
    parts.append("DISABLE_BNB=" + os.environ.get("DISABLE_BNB", ""))
    parts.append("ENABLE_BNB=" + os.environ.get("ENABLE_BNB", ""))
    return ", ".join(parts)


if __name__ == "__main__":
    # Quick local smoke test when run as a script (won't load heavy models)
    logging.basicConfig(level=logging.INFO)
    logger.info("Runtime summary: %s", summarize_runtime())
    # Avoid loading models in the smoke test to keep it fast/safe.
