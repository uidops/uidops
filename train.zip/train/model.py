import torch
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer

# BitsAndBytesConfig may not be available on non-CUDA platforms (e.g. Apple Silicon).
# Import it only if present to avoid import errors when bitsandbytes isn't installed.
try:
    from transformers import BitsAndBytesConfig  # type: ignore

    _HAS_BNB = True
except Exception:
    BitsAndBytesConfig = None  # type: ignore
    _HAS_BNB = False


def load_model_and_tokenizer(config):
    """Load base model and apply LoRA with compatibility for CUDA, MPS (Apple), and CPU.

    - Only use bitsandbytes (4-bit) quantization when CUDA is available and BitsAndBytesConfig
      could be imported.
    - For Apple Silicon (MPS), avoid bitsandbytes and let transformers place the model on MPS.
    - Set torch dtype based on available device and requested fp16 flag.
    - Returns (model, tokenizer, use_bnb, use_mps) where:
      * use_bnb indicates whether bitsandbytes quantization was enabled
      * use_mps indicates whether Apple Metal (MPS) is available on this host
    """

    # Decide whether to use bitsandbytes quantization (only on CUDA and when available)
    use_bnb = (
        torch.cuda.is_available()
        and _HAS_BNB
        and getattr(config, "fp16", False)
    )

    # Quantization config (only when using bitsandbytes)
    bnb_config = None
    if use_bnb:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        config.model_name, trust_remote_code=True
    )

    # Add padding token if missing
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Choose dtype based on device availability
    torch_dtype = None
    use_mps = (
        getattr(torch.backends, "mps", None) is not None
        and torch.backends.mps.is_available()
    )
    if torch.cuda.is_available():
        torch_dtype = torch.float16 if config.fp16 else None
    elif use_mps:
        # On Apple Silicon (MPS), prefer float16 when requested. transformers will place the model
        # on the correct device when device_map="auto" is used.
        torch_dtype = torch.float16 if config.fp16 else None
    else:
        # CPU fallback
        torch_dtype = torch.float32

    # Load model with or without quantization config
    model = AutoModelForCausalLM.from_pretrained(
        config.model_name,
        quantization_config=bnb_config,
        device_map="auto",
        dtype=torch_dtype,
        trust_remote_code=True,
    )

    # for name, module in model.named_modules():
    # print(name)
    # exit()

    # If using bitsandbytes quantization, prepare for k-bit training
    if use_bnb:
        model = prepare_model_for_kbit_training(model)

    # Note: when not using bnb (e.g. MPS or CPU), prepare_model_for_kbit_training should not be called.
    # device_map="auto" ensures the model is placed on CUDA/MPS/CPU appropriately.

    # LoRA configuration
    peft_config = LoraConfig(
        r=config.lora_r,
        lora_alpha=config.lora_alpha,
        lora_dropout=config.lora_dropout,
        target_modules=config.target_modules,
        bias="none",
        task_type="CAUSAL_LM",
    )

    # Apply LoRA
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    return model, tokenizer, use_bnb, use_mps
