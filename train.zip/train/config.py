from dataclasses import dataclass


@dataclass
class LoRAConfig:
    # LoRA parameters
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    target_modules: list = None

    # Model parameters
    # model_name: str = "HooshvareLab/bert-fa-base-uncased"  # Persian BERT
    model_name: str = "flax-community/gpt2-persian-question-answering"
    # Or use: "meta-llama/Llama-2-7b-hf" for generative models

    # Training parameters
    num_epochs: int = 3
    batch_size: int = 4
    learning_rate: float = 2e-4
    max_length: int = 512
    gradient_accumulation_steps: int = 4
    warmup_steps: int = 100

    # Paths
    data_path: str = "/Users/javad/projects/DIVAN-LM/data/normalized_data/only_ai_bonyadvokala.json"
    output_dir: str = "models/lora_model"
    logging_dir: str = "logs"

    # Other
    seed: int = 42
    fp16: bool = True

    def __post_init__(self):
        if self.target_modules is None:
            # For BERT-like models
            # self.target_modules = ["q_proj", "v_proj", "k_proj", "o_proj"]
            self.target_modules = [
                "c_attn",
            ]
            # For LLaMA: ["q_proj", "v_proj", "k_proj", "o_proj"]
