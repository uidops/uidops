import json
from typing import Dict

from torch.utils.data import Dataset
from transformers import PreTrainedTokenizer


class QADataset(Dataset):
    def __init__(
        self,
        data_path: str,
        tokenizer: PreTrainedTokenizer,
        max_length: int = 512
    ):
        with open(data_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx: int) -> Dict:
        item = self.data[idx]

        # Format: Question: ... Answer: ...
        question = item['question']['content']
        answer = item['answer']['content']

        # Create input text
        input_text = f"سوال: {question}\nپاسخ: {answer}"

        # Tokenize
        encoding = self.tokenizer(
            input_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'labels': encoding['input_ids'].squeeze()
        }


class InstructionQADataset(Dataset):
    """For instruction-following models like LLaMA"""
    def __init__(
        self,
        data_path: str,
        tokenizer: PreTrainedTokenizer,
        max_length: int = 512
    ):
        with open(data_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def format_instruction(self, item: Dict) -> str:
        """Format as instruction-following prompt"""
        question = item['question']['content']
        answer = item['answer']['content']

        prompt = f"""### دستورالعمل:
به سوال زیر پاسخ دهید.

### سوال:
{question}

### پاسخ:
{answer}"""

        return prompt

    def __getitem__(self, idx: int) -> Dict:
        item = self.data[idx]
        text = self.format_instruction(item)

        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        return {
            'input_ids': encoding['input_ids'].squeeze(),
            'attention_mask': encoding['attention_mask'].squeeze(),
            'labels': encoding['input_ids'].squeeze()
        }
