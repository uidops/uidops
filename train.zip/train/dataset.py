import json
from typing import Dict

import torch
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizer


class QADataset(Dataset):
    def __init__(
        self,
        data_path: str,
        tokenizer: PreTrainedTokenizer,
        max_length: int = 512,
    ):
        with open(data_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx: int) -> Dict:
        item = self.data[idx]

        # Format: Question: ... Answer: ...
        question = item["question"]["content"]
        answer = item["answer"]["content"]

        # Create input text
        input_text = f"سوال: {question}\nپاسخ: {answer}"

        # Tokenize
        encoding = self.tokenizer(
            input_text,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        return {
            "input_ids": encoding["input_ids"].squeeze(),
            "attention_mask": encoding["attention_mask"].squeeze(),
            "labels": encoding["input_ids"].squeeze(),
        }


class InstructionQADataset(Dataset):
    """For instruction-following models like LLaMA"""

    def __init__(
        self,
        data_path: str,
        tokenizer: PreTrainedTokenizer,
        max_length: int = 512,
    ):
        with open(data_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def _find_sublist(self, full: list, sub: list) -> int:
        """Return start index of sub in full or -1 if not found."""
        if not sub:
            return -1
        # Guard against longer sub than full
        if len(sub) > len(full):
            return -1
        for i in range(len(full) - len(sub) + 1):
            if full[i : i + len(sub)] == sub:
                return i
        return -1

    def __getitem__(self, idx: int) -> Dict:
        item = self.data[idx]
        question = item["question"]["content"]
        answer = item["answer"]["content"]

        messages = [
            {"role": "user", "content": question},
            {"role": "assistant", "content": answer},
        ]

        # Construct ChatML JSON messages and compute assistant token mask by matching
        # the assistant token subsequence inside the tokenized JSON. If matching fails,
        # use a conservative fallback heuristic.
        #
        # We always produce input tokens from the JSON:
        # {"messages": [{"role": "user", "content": ...}, {"role": "assistant", "content": ...}]}
        # and try to locate the assistant item within the tokenized JSON to mask labels.
        chat_obj = {"messages": messages}
        chat_json = json.dumps(chat_obj, ensure_ascii=False)

        # Tokenize the full ChatML JSON
        full_enc = self.tokenizer(
            chat_json,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        full_ids = full_enc["input_ids"][0].tolist()
        attention_mask = full_enc["attention_mask"].squeeze()

        # Build a JSON snippet for the assistant item to search for in the full token sequence
        assistant_item_json = json.dumps(
            {"role": "assistant", "content": answer}, ensure_ascii=False
        )
        assist_enc = self.tokenizer(
            assistant_item_json, add_special_tokens=False, return_tensors="pt"
        )
        assist_ids = assist_enc["input_ids"][0].tolist()

        # Try to locate the assistant snippet inside the full token ids
        start = self._find_sublist(full_ids, assist_ids)
        seq_len = len(full_ids)
        assistant_masks = torch.zeros(seq_len, dtype=torch.bool)

        if start != -1:
            # If found, mark the corresponding span as assistant tokens
            for i in range(start, start + len(assist_ids)):
                if 0 <= i < seq_len:
                    assistant_masks[i] = True
        else:
            # If exact assistant JSON snippet wasn't found, try to match the raw answer tokens
            ans_enc = self.tokenizer(
                answer, add_special_tokens=False, return_tensors="pt"
            )
            ans_ids = ans_enc["input_ids"][0].tolist()
            start = self._find_sublist(full_ids, ans_ids)
            if start != -1:
                for i in range(start, start + len(ans_ids)):
                    if 0 <= i < seq_len:
                        assistant_masks[i] = True
            else:
                # Last-resort fallback: assume assistant tokens occupy the last N non-padded tokens,
                # where N = len(ans_ids). This is conservative and ensures training focuses on assistant output.
                non_pad = full_enc["attention_mask"][0].tolist()
                non_pad_len = sum(non_pad)
                last_n = len(ans_ids) if "ans_ids" in locals() else 1
                start = max(0, non_pad_len - last_n)
                for i in range(start, non_pad_len):
                    if 0 <= i < seq_len:
                        assistant_masks[i] = True

        # Prepare tensors for trainer
        input_ids = full_enc["input_ids"].squeeze()
        attention_mask = full_enc["attention_mask"].squeeze()
        labels = input_ids.clone()

        # Ensure assistant_masks is a tensor of same length and type
        if assistant_masks.numel() != labels.numel():
            # Resize or pad the mask conservatively if lengths differ
            am = torch.zeros_like(labels, dtype=torch.bool)
            am[: min(assistant_masks.numel(), am.numel())] = assistant_masks[
                : am.numel()
            ]
            assistant_masks = am
        else:
            assistant_masks = assistant_masks.to(dtype=torch.bool)

        labels[~assistant_masks] = -100

        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels,
        }
