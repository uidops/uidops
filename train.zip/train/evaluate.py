#!/usr/bin/env python3

import torch
from peft import PeftConfig, PeftModel
from transformers import AutoTokenizer


def load_finetuned_model(model_path: str):
    """Load fine-tuned LoRA model"""
    config = PeftConfig.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(
        config.base_model_name_or_path,
        device_map="auto"
    )
    model = PeftModel.from_pretrained(model, model_path)
    tokenizer = AutoTokenizer.from_pretrained(model_path)

    return model, tokenizer


def generate_answer(model, tokenizer, question: str, max_length: int = 256):
    """Generate answer for a question"""
    prompt = f"""### دستورالعمل:
به سوال زیر پاسخ دهید.

### سوال:
{question}

### پاسخ:
"""

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_length,
            temperature=0.7,
            top_p=0.9,
            do_sample=True
        )

    answer = tokenizer.decode(outputs[0], skip_special_tokens=True)
    # Extract only the answer part
    answer = answer.split("### پاسخ:")[-1].strip()

    return answer


if __name__ == "__main__":
    model, tokenizer = load_finetuned_model("models/lora_model")

    question = "چگونه مشکل تعویض سیلندر خودرو را حل کنم؟"
    answer = generate_answer(model, tokenizer, question)
    print(f"Question: {question}")
    print(f"Answer: {answer}")
